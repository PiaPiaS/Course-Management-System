
package utilities;

public class Constants {
    
    public static final String forNameConstant = "com.mysql.cj.jdbc.Driver";
    public static final String getConnectionNameConstant = "jdbc:mysql://localhost:3306/course_management?user=root&password=&useSSL=false";
    
}
